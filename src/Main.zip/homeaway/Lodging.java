package homeaway;

public interface Lodging {

    double getValue();
    boolean isFull();

}
