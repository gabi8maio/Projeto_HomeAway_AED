package homeaway;

public interface Bookish {
}
