package homeaway;

public interface Students extends Comparable<Students> {
    String getName();
    String getType();
    String getCountry();
    String getLodging ();
}
