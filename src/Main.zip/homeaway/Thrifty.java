package homeaway;

public interface Thrifty {
}
