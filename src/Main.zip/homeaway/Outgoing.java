package homeaway;

public interface Outgoing {
}
