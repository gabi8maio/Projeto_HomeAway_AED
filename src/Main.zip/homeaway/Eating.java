package homeaway;

public interface Eating {
}
