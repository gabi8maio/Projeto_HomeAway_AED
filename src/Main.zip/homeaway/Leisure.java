package homeaway;

public interface Leisure {
}
