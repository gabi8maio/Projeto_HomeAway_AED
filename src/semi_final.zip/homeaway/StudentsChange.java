package homeaway;

public interface StudentsChange {
    void setPlaceHome(Services place);
    void setPlaceGo(Services newPlace);
}