package homeaway;

public interface Eating {

    double getPrice();
}
