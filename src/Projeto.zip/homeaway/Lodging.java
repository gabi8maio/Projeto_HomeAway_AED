package homeaway;

public interface Lodging {
    double getPrice();

}
