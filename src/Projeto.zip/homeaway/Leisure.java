package homeaway;

public interface Leisure {
    double getPrice();

}
