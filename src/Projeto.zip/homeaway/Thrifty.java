package homeaway;

public interface Thrifty {

    boolean isMoreExpensiveThanCheapest(Services services);
}
